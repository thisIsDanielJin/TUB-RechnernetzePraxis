//
// Created by Daniel Wodke on 25.10.24.
//
#include <stdio.h>

int main()
{
  printf("Hello World!");
  return 0;
}
